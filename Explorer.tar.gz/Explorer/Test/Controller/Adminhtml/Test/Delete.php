<?php
 
namespace Explorer\Test\Controller\Adminhtml\Test;
 
class Delete extends \Explorer\Test\Controller\Adminhtml\Test
{
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('test_id');
        if ($id) {
            try {
                 
                $model = $this->_objectManager->create('Explorer\Test\Model\Test');
                $model->load($id);
                $model->delete();
                 
                $this->messageManager->addSuccess(__('You deleted the item.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['test_id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find the item to delete.'));
        return $resultRedirect->setPath('*/*/');
    }
}